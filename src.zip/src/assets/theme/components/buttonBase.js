const buttonBase = {
  defaultProps: {
    disableRipple: true,
  },
};

export default buttonBase;
