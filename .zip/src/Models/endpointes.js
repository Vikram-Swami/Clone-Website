export const createUser = "/register-user";
export const loginUser = "/login";
export const createAddress = "/create-address";
